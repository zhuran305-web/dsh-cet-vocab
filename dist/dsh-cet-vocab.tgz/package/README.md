# dsh-cet-vocab / 背单词（四六级）

A CET-4 / CET-6 vocabulary trainer for the [DeepSeek Harness](https://github.com/deepseek-ai) (dsh) Web UI: a draggable, minimizable floating word-card window you can open any time — including while the model is thinking.

一个 DeepSeek Harness（dsh）Web 界面的四六级背单词悬浮窗：可拖动、可最小化，随时点开背单词——包括模型思考的空档期。

## Features / 功能

- **Word list / 词库** — 5,805 words (CET-4 3,849 / CET-6 5,407, deduplicated), extracted from [ECDICT](https://github.com/skywind3000/ECDICT) by tag and sorted by frequency. The list is bundled into the client, so the plugin works fully offline. 词库按 cet4/cet6 标签从 ECDICT 提取、按词频排序，内嵌进前端，运行时不需要网络。
- **Two study modes / 两种模式** — flip-card with three-button grading (known / fuzzy / unknown), or multiple-choice quiz with distractors picked from confusable words (edit distance, shared prefix/suffix/bigrams). 翻卡三键评分（认识/模糊/不认识），或形近词干扰项的选择题模式。
- **Spaced repetition / 间隔复习** — Ebbinghaus-style ladder (10 min → 1 d → 2 d → 4 d → 8 d → 16 d); failed cards reset and re-queue after 10 minutes. 艾宾浩斯阶梯复习，答错 10 分钟后重新进队。
- **Daily plan / 每日计划** — configurable daily new-word quota (0–500); today's review count shown on the pill badge. 每日新词数可自定义（0–500），药丸徽标显示今日待复习数。
- **Review / extra practice / 复习与加练** — when today's quota is done, review due cards (≤20) or practice 10 unseen words; practice results don't consume the quota. 完成当日额度后可复习到期词或加练未学词，不计额度。
- **Auto-open / 思考时自动弹出** — opens the window automatically whenever a session starts running; toggleable in settings. 检测到会话运行时自动弹出窗口，可在设置中关闭。
- **Pronunciation / 发音** — reads the word via `speechSynthesis`; auto-speak optional. 调用浏览器语音合成读单词，可开自动发音。
- **Window / 窗口** — draggable with pointer capture and edge clamping, minimizes to a badge pill that stays where you left it; geometry persisted. 拖动带边界钳制，最小化成药丸且停在原地，几何持久化。
- **Stats & settings / 统计与设置** — per-book progress and streaks; switch between CET-4 / CET-6 / all books. 各词书进度统计，可切换四级/六级/全部词库。
- **Keyboard / 快捷键** — `Space` reveal, `1/2/3` grade in card mode, `1-4` answer in quiz mode. 卡片模式空格翻面、123 评分，选择题 1-4 作答。

Progress is stored in `localStorage` (per browser profile). 进度存于浏览器 `localStorage`。

## Install / 安装

From any DSH plugin marketplace that mirrors the [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin) catalog (e.g. dshmarket, dsh-plugin-mall), or directly / 或直接：

```sh
dsh plugin add dsh-cet-vocab
```

The package ships prebuilt `client.js` — no build step, no network access, no telemetry. 包内自带构建好的 client.js，无构建步骤、无网络请求、无遥测。

## Build from source / 从源码构建

```sh
node scripts/build_client.mjs   # embeds data/words.json into client.js
```

`data/words.json` is generated from ECDICT (`scripts/build_words.py` filters the `cet4`/`cet6` tags); download the [ECDICT](https://github.com/skywind3000/ECDICT) release CSV to `data/ecdict.csv` to regenerate it.

## Data license / 词库来源

The word list is extracted from [ECDICT](https://github.com/skywind3000/ECDICT) (MIT License, © skywind3000). Everything else is MIT — see [LICENSE](LICENSE).

## License / 许可

MIT
